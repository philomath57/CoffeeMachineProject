menu = {
    "espresso": {
        "ingredients": {
            "water": 50,
            "coffee": 18,
        },
        "cost": 1.5,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 2.5,
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 3.0,
    }
}

resources = {
    "milk": 200,
    "water": 300,
    "coffee": 100
}

is_continue = True
while is_continue:

    user_input = input("What would you like? espresso/latte/cappuccino: ")
    if user_input.lower() == "report":
        print(resources)
    elif user_input.lower() == "espresso" or user_input.lower() == "latte" or user_input.lower() == "cappuccino":
        print("Please Insert Coins.")
        quarters = float(input("How many quarters? "))
        dimes = float(input("How many Dimes? "))
        nickles = float(input("How many Nickles? "))
        pennies = float(input("How many Pennies? "))
        if user_input.lower() == "espresso":
            total_amount_given = quarters / 4 + dimes / 10 + nickles / 20 + pennies / 100
            if total_amount_given >= menu["espresso"]["cost"]:
                if resources["water"] >= menu["espresso"]["ingredients"]["water"]:
                    if resources["coffee"] >= menu["espresso"]["ingredients"]["coffee"]:
                        change_amount = total_amount_given - menu["espresso"]["cost"]
                        resources["water"] = resources["water"] - menu["espresso"]["ingredients"]["water"]
                        resources["coffee"] = resources["coffee"] - menu["espresso"]["ingredients"]["coffee"]
                        print(f"Here is your change ${change_amount}")
                        print("Here is your Espresso. Enjoy!")
                    else:
                        print("Sorry there is no enough Coffee")
                else:
                    print("Sorry there is not enough Water")
            else:
                print("Sorry that's not enough money. Money Refunded.")
        elif user_input.lower() == "latte":
            total_amount_given = quarters / 4 + dimes / 10 + nickles / 20 + pennies / 100
            if total_amount_given >= menu["latte"]["cost"]:
                if resources["water"] >= menu["latte"]["ingredients"]["water"]:
                    if resources["coffee"] >= menu["latte"]["ingredients"]["coffee"]:
                        if resources["milk"] >= menu["latte"]["ingredients"]["milk"]:
                            change_amount = total_amount_given - menu["latte"]["cost"]
                            resources["water"] = resources["water"] - menu["latte"]["ingredients"]["water"]
                            resources["coffee"] = resources["coffee"] - menu["latte"]["ingredients"]["coffee"]
                            resources["milk"] = resources["milk"] - menu["latte"]["ingredients"]["milk"]
                            print(f"Here is your change ${change_amount}")
                            print("Here is your Latte. Enjoy!")
                        else:
                            print("Sorry there is not enough Milk")
                    else:
                        print("Sorry there is not enough Coffee")
                else:
                    print("Sorry there is no enough Water")
            else:
                print("Sorry that's not enough money. Money Refunded.")
        elif user_input.lower() == "cappuccino":
            total_amount_given = quarters / 4 + dimes / 10 + nickles / 20 + pennies / 100
            if total_amount_given >= menu["cappuccino"]["cost"]:
                if resources["water"] >= menu["cappuccino"]["ingredients"]["water"]:
                    if resources["coffee"] >= menu["cappuccino"]["ingredients"]["coffee"]:
                        if resources["milk"] >= menu["cappuccino"]["ingredients"]["milk"]:
                            change_amount = total_amount_given - menu["cappuccino"]["cost"]
                            resources["water"] = resources["water"] - menu["cappuccino"]["ingredients"]["water"]
                            resources["coffee"] = resources["coffee"] - menu["cappuccino"]["ingredients"]["coffee"]
                            resources["milk"] = resources["milk"] - menu["cappuccino"]["ingredients"]["milk"]
                            print(f"Here is your change ${change_amount}")
                            print("Here is your Cappuccino. Enjoy!")
                        else:
                            print("Sorry there is not enough Milk")
                    else:
                        print("Sorry there is not enough Coffee")
                else:
                    print("Sorry there is no enough Water")
            else:
                print("Sorry that's not enough money. Money Refunded.")

    elif user_input.lower() == "no":
        is_continue = False
